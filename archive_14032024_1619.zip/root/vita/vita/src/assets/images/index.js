import logo from "./orebiLogo.png";
import vita from "./vita.png";
import logoLight from "./logoLight.png";
import bannerImgOne from "./banner/bannerFlex.webp";
import bannerImgTwo from "./banner/bannerMan.webp";
import bannerImgBanner from "./banner/allBanner.webp";
import nurzhanBanner from "./banner/nurzhanBanner.webp";
import bannerImgThree from "./banner/alcoBanner.webp";
import bannerImgFour from "./banner/womanBanner.webp";
import saleImgOne from "./sale/manDiscount.png";
import saleImgTwo from "./sale/alcoDiscount.png";
import saleImgThree from "./sale/womanDiscount.png";
import capsule from "./capsule.webp";
import firstCertificate from "./balance.webp";
import secondCertificate from "./balance2.webp";
import kaspi from "./kaspi_logo.webp";
// ============== Products Start here ====================
// New Arrivals
import newArrOne from "./products/newArrival/manBalance.png";
import newArrTwo from "./products/newArrival/bodyBalance.png";
import newArrThree from "./products/newArrival/alcoBalance.png";
import newArrFour from "./products/newArrival/flexBalance.png";
import newArrFive from "./products/newArrival/EroKing.png";
import newArrSix from "./products/newArrival/LibidoForts.png";
import newArrSeven from "./products/newArrival/femBalance.png";

// SVG ICONS
import shopIcon from "./products/svgIcons/shop.svg";
import contractIcon from "./products/svgIcons/contract.svg";
import boxIcon from "./products/svgIcons/box.svg";


// Best Sellers
import bestSellerOne from "./products/bestSeller/bestFemBalance.webp";
import bestSellerTwo from "./products/bestSeller/bestFlexBalance.webp";
import bestSellerThree from "./products/bestSeller/bestAlcoBalance.webp";
import bestSellerFour from "./products/bestSeller/bestManBalance.webp";

// Special Offers
import spfOne from "./products/specialOffer/spfOne.webp";
import spfTwo from "./products/specialOffer/spfTwo.webp";
import spfThree from "./products/specialOffer/spfThree.webp";
import spfFour from "./products/specialOffer/spfFour.webp";

// Year Product
import productOfTheYear from "./products/productOfTheYear.webp";
// ============== Products End here ======================
import paymentCard from "./payment.png";
import emptyCart from "../images/emptyCart.png";


// PRODUCT COURSES
import manbalanceOne from "./courses/manbalanceOne.webp";
import manbalanceTwo from "./courses/manbalanceTwo.webp";
import manbalanceThree from "./courses/manbalanceThree.webp";

import flexbalanceOne from "./courses/flexbalanceOne.webp";
import flexbalanceTwo from "./courses/flexbalanceTwo.webp";
import flexbalanceThree from "./courses/flexbalanceThree.webp";

import fembalanceOne from "./courses/fembalanceOne.webp";
import fembalanceTwo from "./courses/fembalanceTwo.webp";
import fembalanceThree from "./courses/fembalanceThree.webp";

import alcobalanceOne from "./courses/alcobalanceOne.webp";
import alcobalanceTwo from "./courses/alcobalanceTwo.webp";
import alcobalanceThree from "./courses/alcobalanceThree.webp";

import bodybalanceOne from "./courses/bodybalanceOne.webp";
import bodybalanceTwo from "./courses/bodybalanceTwo.webp";
import bodybalanceThree from "./courses/bodybalanceThree.webp";

import libidofortisOne from "./courses/libidofortisOne.webp";
import libidofortisTwo from "./courses/libidofortisTwo.webp";
import libidofortisThree from "./courses/libidofortisThree.webp";

import erokingOne from "./courses/erokingOne.webp";
import erokingTwo from "./courses/erokingTwo.webp";
import erokingThree from "./courses/erokingThree.webp";

// Product Videos
import manBalanceVideo from "./products/productsVideo/100001_first.mp4";
import flexBalanceAnotherVideo from "./products/productsVideo/GifsFlex.mp4";
import flexBalanceFirstPoster from "./products/productsVideo/flexbalancePosterFirst.webp";
import manBalanceAnotherVideo from "./products/productsVideo/10001_second.mp4";
import manBalanceFirstPoster from "./products/productsVideo/manbalancePosterFirst.png";
import manBalanceSecondPoster from "./products/productsVideo/manbalancePosterSecond.png";
export {
   
   //  COURSE
    manbalanceOne,
    manbalanceTwo,
    manbalanceThree,
    
    flexbalanceOne,
    flexbalanceTwo,
    flexbalanceThree,
    
    alcobalanceOne,
    alcobalanceTwo,
    alcobalanceThree,
    
    fembalanceOne,
    fembalanceTwo,
    fembalanceThree,
    
    libidofortisOne,
    libidofortisTwo,
    libidofortisThree,
    
    erokingOne,
    erokingTwo,
    erokingThree,
    
    bodybalanceOne,
    bodybalanceTwo,
    bodybalanceThree,
   
  manBalanceSecondPoster,
  manBalanceAnotherVideo,
  manBalanceFirstPoster,
  flexBalanceAnotherVideo,
  flexBalanceFirstPoster,
  bannerImgBanner,
  firstCertificate,
  secondCertificate,
  vita,
  logo,
  kaspi,
  logoLight,
  bannerImgOne,
  bannerImgTwo,
  bannerImgThree,
  bannerImgFour,
  nurzhanBanner,
  saleImgOne,
  saleImgTwo,
  saleImgThree,
  manBalanceVideo,
  capsule,
  // ===================== Products start here ============
  // New Arrivals
  newArrOne,
  newArrTwo,
  newArrThree,
  newArrFour,
  newArrFive,
  newArrSix,
  newArrSeven,
    
    // Svg ICONS
    boxIcon,
    contractIcon,
    shopIcon,
    
  // Best Sellers
  bestSellerOne,
  bestSellerTwo,
  bestSellerThree,
  bestSellerFour,

  // Sprcial Offers
  spfOne,
  spfTwo,
  spfThree,
  spfFour,

  // Year Product
  productOfTheYear,
  // ===================== Products End here ==============
  paymentCard,
  emptyCart,
};
