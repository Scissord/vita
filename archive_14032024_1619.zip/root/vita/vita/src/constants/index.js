import {
  spfOne,
  spfTwo,
  spfThree,
  spfFour,
  bestSellerOne,
  bestSellerTwo,
  bestSellerThree,
  bestSellerFour,
  newArrOne,
  newArrTwo,
  newArrThree,
  newArrFour,
  newArrFive,
  newArrSix,
  newArrSeven,
  manBalanceVideo,
  manBalanceFirstPoster,
  manBalanceAnotherVideo,
  manBalanceSecondPoster,
  flexBalanceAnotherVideo,
  flexBalanceFirstPoster,
  boxIcon,
  manbalanceOne,
  manbalanceTwo,
  manbalanceThree,
  flexbalanceOne,
  flexbalanceTwo,
  flexbalanceThree,
  fembalanceOne,
  fembalanceTwo,
  fembalanceThree,
  alcobalanceOne,
  alcobalanceTwo,
  alcobalanceThree,
  bodybalanceOne,
  bodybalanceTwo,
  bodybalanceThree,
  libidofortisOne,
  libidofortisTwo,
  libidofortisThree,
  erokingOne,
  erokingTwo,
  erokingThree,
  contractIcon,
  shopIcon
} from "../assets/images/index";











// ===========

// =================== NavBarList Start here ====================
export const navBarList = [
  {
    _id: 1001,
    title: "Главная",
    link: "/",
  },
  {
    _id: 1002,
    title: "Каталог",
    link: "/shop",
  },
  {
    _id: 1003,
    title: "О нас",
    link: "/about",
  },
  {
    _id: 1004,
    title: "Акции",
    link: "/contact",
  },
  
  
  
];




// =================== NavBarList End here ======================

export const ItemsBox = [
{
img: boxIcon,
description: "Доставка по всем городам Казахстана",
title: "Доставка"
},
{
img: shopIcon,
title: "Продавец №1",
description: "в своей категории по всему Казахстану "
},
{
img: contractIcon,
description: "максимальное качество для здоровья.",
title: "Премимум бренд"
}
 ];
// =================== Special Offer data Start here ============
export const SplOfferData = [
  {
    _id: "201",
    img: spfOne,
    productName: "Cap for Boys",
    price: "35.00",
    color: "Blank and White",
    badge: true,
    des: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Hic excepturi quibusdam odio deleniti reprehenderit facilis.",
  },
  {
    _id: "202",
    img: newArrFour,
    productName: "Tea Table",
    price: "180.00",
    color: "Gray",
    badge: true,
    des: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Hic excepturi quibusdam odio deleniti reprehenderit facilis.",
  },
  {
    _id: "203",
    img: spfThree,
    productName: "Headphones",
    price: "25.00",
    color: "Mixed",
    badge: true,
    des: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Hic excepturi quibusdam odio deleniti reprehenderit facilis.",
  },
  {
    _id: "204",
    img: spfFour,
    productName: "Sun glasses",
    price: "220.00",
    color: "Black",
    badge: true,
    des: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Hic excepturi quibusdam odio deleniti reprehenderit facilis.",
  },
];
// =================== Special Offer data End here ==============


 



// =================== SALES and PROMOCODES Start here ==============
export const promoCodes = [
  
  { promo: 'Nurzhan24' , discount: -0.1, },
  
  
  // Добавьте дополнительные промо-коды при необходимости
];


// =================== SALES and PROMOCODES END here ==============

// =================== PaginationItems Start here ===============

export const paginationItems = [
  {
            _id: "202690",
            img: newArrOne,
            productName: "ManBalance",
            price: "54000",
            
            color: "средство для мужчин",
            badge: true,
          
            des: "ManBalance: Инновационная Поддержка Мужской Сексуальной Жизни"
  },

  {
    _id :"204116",
    img: newArrTwo,
    productName:"BodyBalance",
    price:"53990",
    
    color:"средство для быстрого похудения",
    badge:true,
    des:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Hic excepturi quibusdam odio deleniti reprehenderit facilis."
  },
  {
            _id:"204118",
            img:newArrThree,
            productName:"AlcoBalance",
            price:"52990",
            color:"средство от алкозависимости",
            badge:true,
            des: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Hic excepturi quibusdam odio deleniti reprehenderit facilis."
  },
  {
            _id:"202914",
            img:newArrFour,
            productName:"FlexBalance",
            price:"52990",
            color:"средство от болей в суставах",
            badge:true,
            des:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Hic excepturi quibusdam odio deleniti reprehenderit facilis."
  },
  {
            _id:"204117",
            img:newArrFive,
            productName:"EroKing",
            price:"27590",
            color:"средство для мужчин",
            badge:true,
            des:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Hic excepturi quibusdam odio deleniti reprehenderit facilis."
  },
  {
            _id:"204120",
            img:newArrSix,
            productName:"LibidoFortis",
            price:"27990",
            color:"средство для мужчин",
            badge:true,
            des:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Hic excepturi quibusdam odio deleniti reprehenderit facilis."
  },
  {
            _id:"204119",
            img:newArrSeven,
            productName:"FemBalance",
            price:"53290",
            color:"средство для женщин",
            badge:true,
            des:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Hic excepturi quibusdam odio deleniti reprehenderit facilis."
  },
  
];
// =================== PaginationItems End here =================






export const ProductsDetailItems = [
  {
    _id: "202690",
    img: newArrOne,
    productName: "ManBalance",
    price: "54000",
    // priceSec:"97200",
    // priceThr:"129600",
    color: "средство для мужчин",
    badge: true,
    video: manBalanceVideo,
    videoPoster: manBalanceFirstPoster,
    anotherVideo: manBalanceAnotherVideo,
    anotherVideoPoster: manBalanceSecondPoster,
    des: "ManBalance - это передовой препарат, разработанный специально для поддержания и улучшения мужской сексуальной жизни. ",
    des1: 'Уникальное сочетание природных компонентов, таких как Спирулина, Экстракт Маки перуанской, Корень женьшеня, делает ManBalance мощным средством для решения различных проблем в сфере сексуального здоровья мужчины.',
    des2: 'Эффект заметен сразу после первого применения, за 4 недели вы получите желаемый результат. Улучшает качество эрекции и продлевает длительность полового акта,  восстановите свою сексуальную активность с ManBalance уже сегодня!"',
    description: [
      "Регулирует процессы эякуляции, продлевая продолжительность полового акта.",
      "Пониженный тестостерон: Повышает уровень тестостерона, улучшая сексуальное влечение и энергию.",
      "Простатит: Обладает противовоспалительными свойствами, помогая предотвращать и облегчать симптомы простатита.",
      "Ухудшение мужского здоровья: Улучшает эрекцию, делая ее более твердой и стойкой.",
    ],
    customerReviews:
 [
   {
        id: 1,
        name: "Нуржан Казыбеков",
        date: "22 июня 2023",
        content: "Препарат ManBalance реально помог. Улучшилось общее самочувствие и добавилось сил!",
        helpfulCount: 12,
      },
      {
        id: 2,
        name: "Александра Ермакова",
        date: "12 июля 2023",
        content: "Мой муж стал использовать ManBalance и результаты нас обоих устроили. Спасибо!",
        helpfulCount: 19,
      },
      {
        id: 3,
        name: "Тимур Рустемов",
        date: "5 августа 2023",
        content: "Начал принимать ManBalance по совету друга. Заметил положительные изменения уже через неделю.",
        helpfulCount: 7,
      },
  // Add more review objects as needed
],
     listItems: [
    {li: "Низкая либидо"},
    {li: "Эректильная дисфункция"},
    {li: "Простатит"},
    {li: "Ослабленная потенция"},
    {li: "Потеря сексуального влечения"},
],
     priceList: [
        {
            price: "54000",
            desc: '',
            pack: manbalanceOne,
            index:1,
        },
        {
            price: "97200",
            desc: '',
            undiscount: "108000",
            pack: manbalanceTwo,
            index:2,
        },
        {
            price: "129600",
            desc: '',
            undiscount: "162000",
            pack: manbalanceThree,
            index:3,
        }
        ]

    
  },
  {
    _id: "204116",
    img: newArrTwo,
    productName: "BodyBalance",
    price: "53990",
    color: "средство для быстрого похудения",
    badge: true,
    des: "BodyBalance - это эффективное средство для быстрого похудения, разработанное на основе натуральных компонентов.",
    des1: "Благодаря инновационной формуле, BodyBalance активизирует метаболизм, снижает аппетит и ускоряет процесс сжигания жировых запасов.Уникальное сочетание природных компонентов, таких как инозитол, метионин, D,L-холин битартрат; агент антислеживающий: тальк пищевой делает Body-Balance мощным средством для сжигание лишнего веса .",
    des2: "Начните свой путь к стройной фигуре уже сегодня с BodyBalance!",
    description: [
      "Активизирует метаболизм, способствуя быстрому сжиганию жировых запасов.",
      "Снижает аппетит, помогая контролировать калорийный прием.",
      "Ускоряет процесс похудения и формирования стройной фигуры.",
     ],
     customerReviews:
 [
  {
    id: 1,
    name: "Марат Жолдасов",
    date: "12 января 2024",
    content: "С началом приёма BodyBalance я почувствовал новый прилив сил. Вес начал уходить, а жизненный тонус заметно повысился.",
    helpfulCount: 12,
  },
  {
    id: 2,
    name: "Светлана Рязанова",
    date: "27 февраля 2024",
    content: "BodyBalance помог мне восстановить контроль над своим весом после новогодних праздников. Это был настоящий прорыв для меня!",
    helpfulCount: 9,
  },
  {
    id: 3,
    name: "Айдар Нургалиев",
    date: "6 марта 2024",
    content: "Этот препарат стал моим верным помощником на пути к здоровому телу. Рекомендую BodyBalance всем, кто сталкивается с затруднениями в похудении.",
    helpfulCount: 5,
  },
  {
    id: 4,
    name: "Екатерина Иванова",
    date: "20 декабря 2023",
    content: "С BodyBalance я забыла о диетах. Теперь я могу есть все, что люблю, и при этом худею. Это чудо!",
    helpfulCount: 18,
  },
  {
    id: 5,
    name: "Тимур Валеев",
    date: "15 ноября 2023",
    content: "За короткий срок BodyBalance помог мне избавиться от лишних килограммов, которые мешали мне наслаждаться жизнью.",
    helpfulCount: 26,
  },
  // Add more review objects as needed
],
    
     listItems: [
    {li: "Медленный метаболизм"},
    {li: "Недостаток энергии"},
    {li: "Набор лишнего веса"},
    {li: "Трудности в снижении веса"},
    {li: "Отложения жира"},
],
 priceList: [
        {
            price: "53990",
            desc: '',
            pack: bodybalanceOne,
            index:1,
        },
        {
            price: "97182",
             desc: '',
            pack: bodybalanceTwo,
            undiscount: "107980‬",
            index:2,
        },
        {
            price: "129576",
            desc: '',
            pack: bodybalanceThree,
            undiscount: "161970",
            index:3,
        }
        ]

  },
  {
    _id: "204118",
    img: newArrThree,
    productName: "AlcoBalance",
    price: "52990",
    color: "средство от алкозависимости",
    badge: true,
    des: "AlcoBalance - это инновационное средство для борьбы с алкогольной зависимостью.",
    des1: "Специально разработанная формула AlcoBalance помогает уменьшить желание к употреблению алкоголя, улучшает общее самочувствие и помогает восстановить функции организма после злоупотребления алкоголем.Уникальное сочетание природных компонентов, таких как Габа Алишань – формирует полное безразличие к алкоголю, Гинкго билоба – останавливает отмирание клеток мозга, Чай матча делает Alco-Balance мощным средством от алко зависимостей .",
    des2: "Применяйте AlcoBalance для восстановления здоровья и улучшения качества жизни!",
    description: [
      "Уменьшает желание к употреблению алкоголя, помогая преодолеть зависимость.",
      "Улучшает общее самочувствие и физическое состояние организма.",
      "Поддерживает процессы восстановления после злоупотребления алкоголем.",
     ],
     customerReviews:
 [
  {
    id: 1,
    name: "Артем Игнатьев",
    date: "5 февраля 2024",
    content: "AlcoBalance помог мне справиться с тягой к алкоголю. Чувствую себя намного лучше и полон сил.",
    helpfulCount: 8,
  },
  {
    id: 2,
    name: "Светлана Медведева",
    date: "12 марта 2024",
    content: "Препарат действительно работает. Мой муж перестал пить, и наша семья снова счастлива.",
    helpfulCount: 14,
  },
  {
    id: 3,
    name: "Николай Васильев",
    date: "25 января 2024",
    content: "С AlcoBalance моя жизнь изменилась. Я больше не зависим от алкоголя и начал новую жизнь.",
    helpfulCount: 5,
  },
  {
    id: 4,
    name: "Дарина Алексеева",
    date: "9 марта 2024",
    content: "Замечательное средство для борьбы с алкоголизмом. Я смогла оставить пить благодаря AlcoBalance.",
    helpfulCount: 11,
  },
  {
    id: 5,
    name: "Ирина Степанова",
    date: "15 февраля 2024",
    content: "Это средство помогло мне в трудные времена. Благодарю разработчиков за AlcoBalance!",
    helpfulCount: 7,
  },
  // Add more review objects as needed
],
   
     listItems: [
    {li: "Алкогольная зависимость"},
    {li: "Алкогольные кризы"},
    {li: "Социальная деградация"},
    {li: "Риски здоровью"},
    {li: "Семейные проблемы"},
],
 priceList: [
        {
            price: "52990",
            desc: '',
            pack: alcobalanceOne,
            
            index:1,
        },
        {
            price: "95382",
             desc: '',
            pack: alcobalanceTwo,
            undiscount: "105980",
            index:2,
        },
        {
            price: "127176",
            desc: '',
            pack: alcobalanceThree,
            undiscount: "158970",
            index:3,
        }
        ]

  },
  {
    _id: "202914",
    img: newArrFour,
    productName: "Flex-Balance",
    price: "52990",
    video:flexBalanceAnotherVideo,
    videoPoster: flexBalanceFirstPoster,
    // discount:"",
    color: "средство от болей в суставах",
    badge: true,
    des: "FlexBalance - это натуральное средство для снятия болей в суставах и укрепления суставной ткани. Уникальное сочетание природных компонентов, таких как Коллаген, гиалуроновая кислота и витамин С влияют на здоровье опорно-двигательного аппарата делает Flex-Balance мощным средством для решения различных проблем cуставами.",
    des1: "Благодаря уникальной формуле, FlexBalance помогает улучшить подвижность суставов, снять воспаление и уменьшить болевые ощущения.",
    des2: "Восстановите здоровье своих суставов с FlexBalance!",
    description: [
      "Улучшает подвижность суставов и укрепляет суставную ткань.",
      "Снимает воспаление и уменьшает болевые ощущения.",
      "Способствует восстановлению здоровья и функциональности суставов.",
     ],
    customerReviews:
 [
  {
    id: 1,
    name: "Елена Сергеева",
    date: "15 февраля 2024",
    content: "FlexBalance помог мне избавиться от болей в коленях, которые мешали мне заниматься спортом. Очень благодарна!",
    helpfulCount: 26,
  },
  {
    id: 2,
    name: "Игорь Николаев",
    date: "3 марта 2024",
    content: "После двух недель использования FlexBalance мои суставы стали значительно лучше. Рекомендую данный продукт!",
    helpfulCount: 14,
  },
  {
    id: 3,
    name: "Мария Иванова",
    date: "21 января 2024",
    content: "FlexBalance стал настоящим спасением для моих суставов. Теперь могу заниматься садоводством без дискомфорта.",
    helpfulCount: 19,
  },
  {
    id: 4,
    name: "Азамат Қали",
    date: "28 февраля 2024",
    content: "Благодарю за FlexBalance! Чувствую облегчение и подвижность в суставах, которых не было уже долгое время.",
    helpfulCount: 22,
  },
  // Add more review objects as needed
],

      listItems: [
    {li: "Артрит"},
    {li: "Остеоартроз"},
    {li: "Ревматоидный артрит"},
    {li: "Бурсит"},
    {li: "Травмы суставов"},
],
  priceList: [
        {
            price: "52990",
            desc: '',
            pack: flexbalanceOne,
            
            index:1,
        },
        {
            price: "95382",
            desc: '',
            pack: flexbalanceTwo,
            undiscount: "105980‬",
            index:2,
        },
        {
            price: "127176",
            desc: '',
            pack: flexbalanceThree,
             undiscount: "158970",
            index:3,
        }
        ]
    
  },
  {
    _id: "204117",
    img: newArrFive,
    productName: "EroKing",
    price: "27590",
    color: "средство для мужчин",
    badge: true,
    des: "EroKing - это высокоэффективное средство для улучшения мужской сексуальной функции и повышения потенции.Уникальное сочетание природных компонентов, таких как Спирулина, Экстракт Маки перуанской, Корень женьшеня, делает EroKing мощным средством для решения различных проблем в сфере сексуального здоровья мужчины.",
    des1: "Специально разработанная формула EroKing активизирует кровообращение в области малого таза, усиливает эрекцию и улучшает сексуальные ощущения.",
    des2: "Почувствуйте себя настоящим королем в постели с EroKing!",
    description: [
      "Усиливает эрекцию и повышает потенцию.",
      "Повышает сексуальное влечение и улучшает сексуальные ощущения.",
      "Способствует улучшению сексуальной функции и увеличению выносливости.",
    ],
    customerReviews:
 [
  {
    id: 1,
    name: "Айдар Нурмагамбетов",
    date: "15 февраля 2024",
    content: "После двух недель применения EroKing я заметил значительные улучшения. Очень доволен результатом!",
    helpfulCount: 22,
  },
  {
    id: 2,
    name: "Владимир Еремин",
    date: "3 марта 2024",
    content: "EroKing помог мне вернуть уверенность в себе. Рекомендую всем, кто столкнулся с подобными проблемами!",
    helpfulCount: 17,
  },
  {
    id: 3,
    name: "Екатерина Иванова",
    date: "21 января 2024",
    content: "Мой муж стал использовать EroKing, и мы оба заметили изменения к лучшему. Спасибо за такой продукт!",
    helpfulCount: 35,
  },
  {
    id: 4,
    name: "Тимур Болатович",
    date: "28 января 2024",
    content: "Препарат EroKing реально работает. Улучшилась не только потенция, но и общее состояние.",
    helpfulCount: 29,
  },
  // Add more review objects as needed
],
   
       listItems: [
    {li: "Низкая либидо"},
    {li: "Эректильная дисфункция"},
    {li: "Простатит"},
    {li: "Ослабленная потенция"},
    {li: "Потеря сексуального влечения"},
],
  priceList: [
        {
            price: "27590",
            desc: '',
            pack: erokingOne,
            
            index:1,
            
        },
        {
            price: "49662",
            desc: '',
            pack: erokingTwo,
            undiscount: "55180",
            index:2,
        },
        {
            price: "66216",
            desc: '',
            pack: erokingThree,
            undiscount: "82770‬",
            index:3,
        }
        ]
  },
  {
    _id: "204120",
    img: newArrSix,
    productName: "LibidoFortis",
    price: "27990",
    color: "средство для мужчин",
    badge: true,
    des: "LibidoFortis - это натуральный препарат для улучшения мужской потенции и повышения сексуальной активности.Уникальное сочетание природных компонентов, таких как Спирулина, Экстракт Маки перуанской, Корень женьшеня, делает LibidoFortis мощным средством для решения различных проблем в сфере сексуального здоровья мужчины.",
    des1: "Специально разработанная формула LibidoFortis активизирует кровообращение в области малого таза, усиливает эрекцию и улучшает сексуальные ощущения.",
    des2: "Получите максимум удовольствия от сексуальных отношений с LibidoFortis!",
    description: [
      "Увеличивает сексуальное влечение и желание.",
      "Усиливает эрекцию и продлевает продолжительность полового акта.",
      "Повышает сексуальную активность и улучшает качество сексуальных отношений.",
     ],
     customerReviews:
 [
  {
    id: 1,
    name: "Артур Есенбаев",
    date: "5 ноября 2023",
    content: "LibidoFortis действительно помогает. Чувствую себя гораздо лучше и увереннее.",
    helpfulCount: 12,
  },
  {
    id: 2,
    name: "Ирина Волкова",
    date: "22 января 2024",
    content: "Мой муж начал принимать LibidoFortis, и наши отношения значительно улучшились. Спасибо за ваш продукт!",
    helpfulCount: 27,
  },
  {
    id: 3,
    name: "Олег Киреев",
    date: "17 февраля 2024",
    content: "С LibidoFortis я обрел новую жизнь. Эффективность на высоте!",
    helpfulCount: 19,
  },
  // Add more review objects as needed
],
  
       listItems: [
    {li: "Низкая либидо"},
    {li: "Эректильная дисфункция"},
    {li: "Простатит"},
    {li: "Ослабленная потенция"},
    {li: "Потеря сексуального влечения"},
],
 priceList: [
        {
            price: "27990",
             desc: '',
            pack: libidofortisOne,
            index:1,
            
        },
        {
            price: "50382",
             desc: '',
            pack: libidofortisTwo,
            undiscount: "55980",
            index:2,
        },
        {
            price: "67176",
           desc: '',
            pack: libidofortisThree,
            undiscount: "83970",
            index:3,
        }
        ]
  },
  {
    _id: "204119",
    img: newArrSeven,
    productName: "FemBalance",
    price: "53290",
    color: "средство для женщин",
    badge: true,
    des: "FemBalance - это инновационное средство для поддержания женского здоровья и улучшения качества жизни.",
    des1: "Сбалансированная формула FemBalance, обогащенная витаминами и минералами, помогает нормализовать гормональный фон, улучшить состояние кожи и волос, а также повысить уровень энергии и жизненных сил.Уникальное сочетание природных компонентов, таких как Коллаген гидролизованный, витамин E (DL-альфа-токоферола ацетат) , носитель микрокристаллическая целлюлоза, экстракт шиповника; экстракт ортилии однобокой; экстракт родиолы розовой; корень ашвагандхи;.",
    des2: "Освободите свою женскую энергию с FemBalance!",
    description: [
      "Нормализует гормональный фон и поддерживает женское здоровье.",
      "Улучшает состояние кожи, волос и ногтей.",
      "Повышает уровень энергии и жизненных сил.",
     ],
    customerReviews:
 [
   {
    id: 1,
    name: "Екатерина Васильева",
    date: "8 марта 2024",
    content: "FemBalance стал настоящим спасением для меня. Улучшилось общее самочувствие, и я чувствую себя полной энергии. Кожа и волосы также выглядят лучше!",
    helpfulCount: 26,
  },
  {
    id: 2,
    name: "Алина Каримова",
    date: "21 февраля 2024",
    content: "После начала приема FemBalance, я заметила, как мое состояние заметно улучшилось. Гормональный фон стабилизировался, и я почувствовала прилив сил.",
    helpfulCount: 34,
  },
  {
    id: 3,
    name: "Мария Ильинова",
    date: "15 января 2024",
    content: "Использую FemBalance уже два месяца и не могу нарадоваться на результаты. Это действительно работает, и я рекомендую его всем своим подругам.",
    helpfulCount: 19,
  },
  {
    id: 4,
    name: "Дарья Громова",
    date: "2 декабря 2023",
    content: "Удивительно, но FemBalance помог мне восстановить баланс и энергию. Теперь я чувствую себя намного лучше, и мои дни стали ярче и продуктивнее.",
    helpfulCount: 22,
  },
  // Add more review objects as needed
],

    listItems: [
    {li: "Менопауза"},
    {li: "ПМС (предменструальный синдром)"},
    {li: "Нарушения менструального цикла"},
    {li: "Гормональный дисбаланс"},
    {li: "Проблемы с кожей"},
],
  priceList: [
        {
            price: "53290",
             desc: '',
            pack: fembalanceOne,
            index:1,
            
        },
        {
            price: "95922",
             desc: '',
             undiscount: "106580",
            pack: fembalanceTwo,
            index:2,
        },
        {
            price: "127896",
            desc: '',
            pack: fembalanceThree,
             undiscount: "159870",
            index:3,
        }
        ]

  }
];
